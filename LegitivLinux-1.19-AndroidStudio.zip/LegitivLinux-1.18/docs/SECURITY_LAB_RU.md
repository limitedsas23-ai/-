# Security Lab

Встроенный набор предназначен для диагностики и тестирования систем, которыми вы владеете или на которые у вас есть разрешение.

Функции: сведения о системе, CPU/RAM, интерфейсы, маршруты, DNS, ping, DNS lookup, HTTP headers, TLS certificate, локальные listening ports, процессы, диск, пакеты, SHA-256, Base64, JWT payload decode, environment, проверка world-writable файлов /tmp, APT simulation, версии PRoot/Box64/Wine.

В приложении нет функций брутфорса, эксплуатации уязвимостей, кражи учётных данных или скрытого доступа.
