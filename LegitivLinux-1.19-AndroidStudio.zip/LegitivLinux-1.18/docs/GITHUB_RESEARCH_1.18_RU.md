# GitHub research — LegitivLinux 1.18.1

Исследование подтверждает архитектуру PRoot → ARM64 Debian → Box64 → x86_64 Wine → DXVK.

PRoot-Distro официально предназначен для запуска Linux userland без root на Android/Termux и поддерживает ARM64. Box64 имеет отдельные ARM64 и Android/Termux улучшения. Winlator показывает практическую связку Wine + Box64 + PRoot + DXVK на Android.

Источники:
- https://github.com/termux/proot
- https://github.com/termux/proot-distro
- https://github.com/ptitSeb/box64
- https://github.com/doitsujin/dxvk
- https://github.com/winebox64/winlator

В проекте намеренно нет неподтверждённых бинарников. Версии компонентов выбираются upstream/bootstrap-скриптом, а критические архивы проверяются по SHA-256 там, где фиксированный checksum известен.
