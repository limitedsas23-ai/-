@rem LegitivLinux Gradle Wrapper for Windows
@rem Run ./gradlew assembleDebug
