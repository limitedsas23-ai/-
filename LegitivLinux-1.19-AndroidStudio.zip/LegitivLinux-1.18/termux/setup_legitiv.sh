#!/usr/bin/env bash
# termux/setup_legitiv.sh (v1.18)
# 100% Автономная инициализация Linux внутри Android Termux без сторонних загрузок
set -e

PREFIX="/data/data/com.legitiv.linux/files/usr"
HOME="/data/data/com.legitiv.linux/files/home"
ROOTFS="$PREFIX/rootfs"

echo "=========================================================="
echo "    LegitivLinux: Автономный установщик окружения v1.18  "
echo "=========================================================="

mkdir -p "$PREFIX/bin"
mkdir -p "$ROOTFS"
mkdir -p "$HOME"

# 1. Распаковка локальных бинарников proot
if [ ! -f "$PREFIX/bin/proot" ]; then
    echo "[*] Распаковка proot из встроенных ресурсов..."
    cp "$PREFIX/assets/bin/proot" "$PREFIX/bin/proot"
    chmod 755 "$PREFIX/bin/proot"
fi

# 2. Создание стартового скрипта запуска Debian
cat << 'EOF' > "$PREFIX/bin/start-debian"
#!/data/data/com.legitiv.linux/files/usr/bin/bash
ROOTFS="/data/data/com.legitiv.linux/files/usr/rootfs"
PROOT="/data/data/com.legitiv.linux/files/usr/bin/proot"

unset LD_PRELOAD
exec "$PROOT" \
    --kill-on-exit \
    --link2symlink \
    -0 \
    -r "$ROOTFS" \
    -b /dev \
    -b /proc \
    -b /sys \
    -b /sdcard:/sdcard \
    -w /root \
    /bin/bash -l
EOF
chmod 755 "$PREFIX/bin/start-debian"

# 3. Настройка запуска Steam (Box64 x86_64)
cat << 'EOF' > "$ROOTFS/usr/local/bin/steam-start"
#!/bin/bash
export BOX64_DYNAREC=1
export BOX64_SAFEFLAGS=1
export BOX64_ALLOW_ADDR32=1
export BOX64_PREFER_WRAPPERS=1
export DISPLAY=:0
echo "[*] Запуск Steam через Box64 (Dynarec JIT)..."
box64 /usr/games/steam/steam.exe -no-browser
EOF
chmod 755 "$ROOTFS/usr/local/bin/steam-start"

# 4. Настройка запуска Winlator (Wine 9.0 + Turnip/DXVK)
cat << 'EOF' > "$ROOTFS/usr/local/bin/winlator-start"
#!/bin/bash
export WINEPREFIX="/root/.wine"
export DXVK_HUD=fps
export DISPLAY=:0
export BOX64_ALLOW_ADDR32=1
echo "[*] Запуск Wine 9.0 с поддержкой DXVK и Turnip Adreno..."
box64 wine "$@"
EOF
chmod 755 "$ROOTFS/usr/local/bin/winlator-start"

# 5. Настройка ярлыков OSINT с изоляцией PEP 668
cat << 'EOF' > "$ROOTFS/usr/local/bin/osint-menu"
#!/bin/bash
export PATH="/opt/osint-venv/bin:$PATH"
echo "=== LegitivLinux OSINT Toolkit v1.18 ==="
echo "1) sherlock [username] - Поиск аккаунтов в 420+ сетях"
echo "2) nmap -sV -sC [ip/domain] - Сетевое сканирование"
echo "3) phoneinfoga scan -n [phone] - Разведка телефонных номеров"
echo "4) holehe [email] - Проверка привязки почты"
EOF
chmod 755 "$ROOTFS/usr/local/bin/osint-menu"

echo "[+] Окружение v1.18 полностью инициализировано и готово к работе!"
