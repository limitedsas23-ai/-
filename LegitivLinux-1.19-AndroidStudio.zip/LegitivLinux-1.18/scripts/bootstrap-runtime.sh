#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
PREFIX="${PREFIX:-$HOME/../usr}"
ROOT="$HOME/legitiv-runtime"
mkdir -p "$ROOT"
echo '[1/6] Installing Termux prerequisites...'
pkg update -y
pkg install -y proot proot-distro git cmake make clang tar xz-utils wget curl

echo '[2/6] Installing ARM64 Debian with PRoot-Distro...'
proot-distro install debian || true
proot-distro login debian -- bash -lc 'apt update && apt install -y ca-certificates git cmake build-essential pkg-config wget curl python3 cabextract unzip iproute2 iputils-ping dnsutils openssl procps psmisc net-tools'

echo '[3/6] Building Box64 for ARM64...'
proot-distro login debian -- bash -lc '
set -e
if [ ! -x /usr/local/bin/box64 ]; then
  rm -rf /tmp/box64
  git clone --depth 1 --branch v0.4.4 https://github.com/ptitSeb/box64.git /tmp/box64
  cmake -S /tmp/box64 -B /tmp/box64/build -DARM_DYNAREC=ON -DCMAKE_BUILD_TYPE=Release
  cmake --build /tmp/box64/build -j"$(nproc)"
  install -m 755 /tmp/box64/build/box64 /usr/local/bin/box64
fi
box64 --version || true
'

echo '[4/6] Installing x86_64 Wine dependencies through Debian multiarch...'
proot-distro login debian -- bash -lc '
set -e
if ! dpkg --print-foreign-architectures | grep -qx amd64; then dpkg --add-architecture amd64; fi
apt update
apt install -y wine:amd64 wine64:amd64
'

echo '[5/6] Installing DXVK from upstream release source...'
proot-distro login debian -- bash -lc '
set -e
mkdir -p /opt/dxvk
python3 - <<"PY"
import json, urllib.request
api="https://api.github.com/repos/doitsujin/dxvk/releases/latest"
r=json.load(urllib.request.urlopen(api))
assets=[a for a in r["assets"] if a["name"].endswith(".tar.gz")]
if not assets: raise SystemExit("No DXVK archive asset found")
a=assets[0]
print(a["browser_download_url"])
PY
URL=$(python3 - <<"PY"
import json, urllib.request
r=json.load(urllib.request.urlopen("https://api.github.com/repos/doitsujin/dxvk/releases/latest"))
print(next(a["browser_download_url"] for a in r["assets"] if a["name"].endswith(".tar.gz")))
PY
)
wget -q --show-progress -O /tmp/dxvk.tar.gz "$URL"
rm -rf /tmp/dxvk && mkdir /tmp/dxvk
tar -xzf /tmp/dxvk.tar.gz -C /tmp/dxvk --strip-components=1
cp -a /tmp/dxvk/x32 /opt/dxvk/ 2>/dev/null || true
cp -a /tmp/dxvk/x64 /opt/dxvk/ 2>/dev/null || true
'

echo '[6/6] Installing SteamCMD (x86_64) and writing launcher configuration...'

proot-distro login debian -- bash -lc '
set -e
mkdir -p /opt/steamcmd
cd /opt/steamcmd
wget -q --show-progress -O steamcmd.tar.gz https://steamcdn-a.akamaihd.net/client/installer/steamcmd_linux.tar.gz
tar -xzf steamcmd.tar.gz
rm -f steamcmd.tar.gz
cat >/usr/local/bin/legitiv-steamcmd <<"SH"
#!/bin/sh
exec box64 /opt/steamcmd/steamcmd.sh "$@"
SH
chmod +x /usr/local/bin/legitiv-steamcmd
'

echo
 echo 'LegitivLinux runtime bootstrap complete.'
echo 'PRoot: Termux package | Debian: PRoot-Distro | Box64: upstream | Wine: Debian packages | DXVK: upstream | SteamCMD: Valve'

echo 'The full Steam GUI still requires a working X11/Wayland/Vulkan presentation path on the Android device.'
