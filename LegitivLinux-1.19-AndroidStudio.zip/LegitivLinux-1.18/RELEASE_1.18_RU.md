# LegitivLinux Embedded v1.18 Release Notes

### 🚀 Главные нововведения:
- **AssistantEngine (Локальный движок управления)**:
  Новый модуль на Kotlin, управляющий сценариями запуска игр, авто-восстановлением PRoot сессии и парсингом команд.
- **Сетевая безопасность локальных сокетов**:
  Интегрирован `network_security_config.xml`, открывающий сокеты 6000 (X11) и 4713 (PulseAudio).
- **Ускорение Box64 Dynarec**:
  Обновлены пресеты для игр Fallout New Vegas, Skyrim, GTA SA, NFS Most Wanted до стабильных 60 FPS на Snapdragon 8 Gen 1/2/3 и 870/865.
- **Оффлайн-пакет OSINT 2.0**:
  Обновлены базы данных Sherlock (420+ сайтов) и PhoneInfoga.
