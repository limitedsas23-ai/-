#!/usr/bin/env bash
set -euo pipefail
URL="https://raw.githubusercontent.com/gradle/gradle/v9.4.1/gradle/wrapper/gradle-wrapper.jar"
out="$(dirname "$0")/../gradle/wrapper/gradle-wrapper.jar"
mkdir -p "$(dirname "$out")"
curl -fL --retry 3 "$URL" -o "$out"
echo "Installed Gradle 9.4.1 wrapper jar: $out"
