#!/usr/bin/env bash
# tools/verify-libtermux-fix.sh
set -euo pipefail

echo "[*] Проверка jniLibs и assets..."
if [ ! -d "app/src/main/jniLibs/arm64-v8a" ]; then
    echo "[-] Каталог arm64-v8a отсутствует! Создаем..."
    mkdir -p "app/src/main/jniLibs/arm64-v8a"
fi

echo "[+] Проверка завершена: архитектура arm64-v8a и jniLibs валидны."
