#!/usr/bin/env bash
# tools/verify-release.sh
set -e
echo "[*] Верификация манифеста..."
grep -q "networkSecurityConfig" app/src/main/AndroidManifest.xml && echo "[+] NetworkSecurityConfig OK"
grep -q "AssistantEngine" app/src/main/java/com/legitiv/linux/MainActivity.kt && echo "[+] AssistantEngine OK"
grep -q "BOX64_ALLOW_ADDR32" app/src/main/java/com/legitiv/linux/WineGamingManager.kt && echo "[+] Box64 32-bit mapping OK"
echo "[+] Релиз 1.18 полностью верифицирован!"
