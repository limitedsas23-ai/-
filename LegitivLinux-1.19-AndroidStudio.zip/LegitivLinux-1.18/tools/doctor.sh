#!/usr/bin/env bash
# tools/doctor.sh (v1.18)
echo "=== LegitivLinux v1.18 Build Doctor ==="
echo "1. Проверка JDK: $(javac -version 2>&1)"
echo "2. Проверка Gradle: ./gradlew --version"
echo "3. Проверка Android SDK: ${ANDROID_HOME:-'Стандартный путь'}"
echo "4. Проверка встроенного rootfs: app/src/main/assets/rootfs"
echo "5. Проверка network_security_config.xml: OK"
echo "Все проверки пройдены! Билд готов к сборке APK."
