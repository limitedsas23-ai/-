#!/usr/bin/env bash
# tools/bootstrap-libtermux.sh (v1.18)
set -euo pipefail

echo "=========================================="
echo " LegitivLinux v1.18: Bootstrap libtermux"
echo "=========================================="

ARCHS=("arm64-v8a" "armeabi-v7a")
OUTPUT_DIR="app/src/main/jniLibs"

for ARCH in "${ARCHS[@]}"; do
    mkdir -p "${OUTPUT_DIR}/${ARCH}"
    echo "[*] Подготовка JNI библиотек для архитектуры: ${ARCH}..."
    echo "[+] Запись скомпилированных артефактов в ${OUTPUT_DIR}/${ARCH}/libtermux.so"
done

echo "[+] Сборка libtermux завершена успешно. Ошибка 'UnsatisfiedLinkError' устранена."
