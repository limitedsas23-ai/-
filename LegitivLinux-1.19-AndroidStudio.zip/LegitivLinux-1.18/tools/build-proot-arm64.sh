#!/usr/bin/env bash
set -euo pipefail

# Build a real ARM64 PRoot binary for bundling into the APK.
# Requires Android Studio SDK/NDK and a working git/cmake toolchain.
: "${ANDROID_NDK_HOME:=${ANDROID_HOME:-}/ndk/28.2.13676358}"
if [[ ! -d "$ANDROID_NDK_HOME" ]]; then
  echo "ANDROID_NDK_HOME is not set or does not exist: $ANDROID_NDK_HOME" >&2
  exit 1
fi
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/.build/proot"
OUT="$ROOT/app/src/main/assets/bin/proot"
mkdir -p "$ROOT/.build" "$ROOT/app/src/main/assets/bin"
if [[ ! -d "$SRC/.git" ]]; then
  git clone --depth 1 --branch v5.4.1 https://gitlab.com/proot/proot.git "$SRC"
fi
cmake -S "$SRC" -B "$ROOT/.build/proot-android" \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-26 -DCMAKE_BUILD_TYPE=Release \
  -DANDROID_STL=c++_static
cmake --build "$ROOT/.build/proot-android" --target proot -j"$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)"
BIN=$(find "$ROOT/.build/proot-android" -type f -name proot -perm -111 | head -1)
[[ -n "$BIN" ]] || { echo "PRoot binary not found after build" >&2; exit 1; }
cp "$BIN" "$OUT"
chmod 0755 "$OUT"
file "$OUT" || true
sha256sum "$OUT"
