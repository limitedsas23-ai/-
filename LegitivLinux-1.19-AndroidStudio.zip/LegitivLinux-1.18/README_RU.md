# LegitivLinux 1.19

Android launcher for a rootless Debian ARM64 environment using PRoot. Runtime components are installed by bootstrap and verified where upstream checksums are available.

## Build
- Android Gradle Plugin 9.2.0
- Gradle 9.4.1
- Kotlin 2.2.10
- JDK 17
- compileSdk/targetSdk 36

## Runtime
Debian ARM64 + PRoot + optional Box64/Wine/DXVK/SteamCMD. Full graphical Steam/Wine gaming depends on the device GPU, Vulkan path and Android restrictions.

## Security Lab
Includes defensive/authorized diagnostics: system info, network interfaces/routes, DNS, ping, HTTP/TLS inspection, local listening sockets, processes, disk/package audit, SHA-256, Base64, JWT payload decoding and runtime version checks. It is intended for systems you own or are authorized to test.
