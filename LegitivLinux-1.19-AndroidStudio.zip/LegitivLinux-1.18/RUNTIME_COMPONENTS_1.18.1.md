# Runtime components 1.19

- PRoot: build from upstream PRoot v5.4.1 for arm64-v8a using the Android NDK helper.
- Debian ARM64: official Termux PRoot-Distro rootfs, verified by SHA-256.
- Box64: ptitSeb/box64 v0.4.4, ARM64 dynarec build.
- Wine: Debian package set inside the guest; exact version follows the Debian repository.
- DXVK: current upstream release downloaded by bootstrap.
- Steam: SteamCMD bootstrap is included. Full Steam GUI is optional and depends on the Android graphics/display stack.
