package com.legitiv.linux

/** Safe security/diagnostic helpers intended for systems the user owns or is authorized to test. */
object SecurityToolkit {
    data class Action(val title: String, val needsInput: Boolean = false, val hint: String = "", val command: (String?) -> String)

    fun actions(): List<Action> = listOf(
        Action("Сведения о системе") { "uname -a; echo; cat /etc/os-release 2>/dev/null; echo; id" },
        Action("CPU и память") { "echo CPU:; lscpu 2>/dev/null | head -25; echo; echo RAM:; free -h 2>/dev/null || cat /proc/meminfo | head" },
        Action("Сетевые интерфейсы") { "ip -br addr 2>/dev/null || cat /proc/net/dev" },
        Action("Таблица маршрутов") { "ip route 2>/dev/null || cat /proc/net/route" },
        Action("DNS-конфигурация") { "cat /etc/resolv.conf; echo; getent hosts localhost 2>/dev/null || true" },
        Action("Проверка доступности хоста", true, "example.com") { h -> "timeout 5 ping -c 4 -- ${shell(h)} 2>&1 || true" },
        Action("DNS lookup", true, "example.com") { h -> "getent ahosts ${shell(h)} 2>&1 || nslookup ${shell(h)} 2>&1 || true" },
        Action("HTTP-заголовки", true, "https://example.com") { u -> "curl -I -L --max-time 10 -- ${shell(u)} 2>&1 || true" },
        Action("TLS-сертификат", true, "example.com:443") { h -> "echo | timeout 10 openssl s_client -connect ${shell(h)} -servername ${shell(h?.substringBefore(':'))} 2>/dev/null | openssl x509 -noout -subject -issuer -dates 2>&1 || true" },
        Action("Локальные listening-порты") { "ss -lntup 2>/dev/null || cat /proc/net/tcp /proc/net/tcp6" },
        Action("Процессы") { "ps aux 2>/dev/null || ps -ef" },
        Action("Диск и каталоги") { "df -h; echo; du -sh /root 2>/dev/null || true" },
        Action("Установленные пакеты") { "dpkg-query -W -f='${'$'}{Package} ${'$'}{Version}\n' 2>/dev/null | head -200 || true" },
        Action("SHA-256 файла", true, "/path/to/file") { f -> "sha256sum -- ${shell(f)} 2>&1 || true" },
        Action("Base64 файла", true, "/path/to/file") { f -> "base64 -- ${shell(f)} 2>&1 || true" },
        Action("Decode JWT payload", true, "eyJ...") { token -> "python3 -c 'import base64,json,sys; p=sys.argv[1].split(\".\")[1]; p += \"=\"*((4-len(p)%4)%4); print(json.dumps(json.loads(base64.urlsafe_b64decode(p)),indent=2))' ${shell(token)} 2>&1 || true" },
        Action("Переменные окружения") { "env | sort" },
        Action("Безопасность файлов /tmp") { "find /tmp -maxdepth 2 -type f -perm -0002 -ls 2>/dev/null | head -100 || true" },
        Action("Состояние APT") { "apt-get -s upgrade 2>/dev/null | tail -30 || true" },
        Action("Версии PRoot / Box64 / Wine") { "echo PRoot:; proot --version 2>/dev/null || true; echo Box64:; box64 --version 2>/dev/null || true; echo Wine:; wine --version 2>/dev/null || true" }
    )

    private fun shell(value: String?): String = "'" + (value ?: "").replace("'", "'\"'\"'") + "'"
}
