package com.legitiv.linux

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import android.net.Uri
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.app.AlertDialog
import android.view.inputmethod.InputMethodManager
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var terminalOutput: TextView
    private lateinit var scrollView: ScrollView
    private lateinit var statusText: TextView
    private lateinit var prootInstaller: ProotInstaller
    private lateinit var assistantEngine: AssistantEngine
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        terminalOutput = findViewById(R.id.terminal_output)
        scrollView = findViewById(R.id.terminal_scroll)
        statusText = findViewById(R.id.status_text)
        prootInstaller = ProotInstaller(this)
        assistantEngine = AssistantEngine(this)
        setupUI(); checkPermissions(); startBackgroundService(); checkPhantomProcessKiller(); initializeEnvironment()
    }

    private fun setupUI() {
        findViewById<Button>(R.id.btn_launch_debian).setOnClickListener { run(AssistantEngine.LaunchMode.DEBIAN_SHELL) }
        findViewById<Button>(R.id.btn_launch_steam).setOnClickListener { run(AssistantEngine.LaunchMode.STEAM_LITE) }
        findViewById<Button>(R.id.btn_launch_winlator).setOnClickListener { run(AssistantEngine.LaunchMode.WINLATOR_GAME, "explorer.exe") }
        findViewById<Button>(R.id.btn_launch_osint).setOnClickListener { run(AssistantEngine.LaunchMode.OSINT_SUITE, "osint-menu") }
        findViewById<Button>(R.id.btn_fix_phantom).setOnClickListener { showPhantomProcessGuide() }
        findViewById<Button>(R.id.btn_security_lab).setOnClickListener { showSecurityLab() }
    }

    private fun run(mode: AssistantEngine.LaunchMode, arg: String = "") {
        appendTerminal("\n[>>>] ${mode.name}")
        scope.launch(Dispatchers.IO) {
            prootInstaller.executeInProot(assistantEngine.generateLaunchScript(mode, arg), ::appendTerminal)
        }
    }

    private fun showSecurityLab() {
        val actions = SecurityToolkit.actions()
        AlertDialog.Builder(this)
            .setTitle("Security Lab • authorized use")
            .setItems(actions.map { it.title }.toTypedArray()) { _, which ->
                val action = actions[which]
                if (action.needsInput) {
                    val input = EditText(this).apply {
                        hint = action.hint
                        singleLine = true
                    }
                    AlertDialog.Builder(this)
                        .setTitle(action.title)
                        .setView(input)
                        .setNegativeButton("Отмена", null)
                        .setPositiveButton("Запуск") { _, _ ->
                            appendTerminal("\n[SECURITY] ${action.title}")
                            scope.launch(Dispatchers.IO) {
                                prootInstaller.executeInProot(action.command(input.text.toString()), ::appendTerminal)
                            }
                        }.show()
                } else {
                    appendTerminal("\n[SECURITY] ${action.title}")
                    scope.launch(Dispatchers.IO) {
                        prootInstaller.executeInProot(action.command(null), ::appendTerminal)
                    }
                }
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun appendTerminal(text: String) = runOnUiThread {
        terminalOutput.append(text + "\n")
        scrollView.post { scrollView.fullScroll(View.FOCUS_DOWN) }
    }

    private fun initializeEnvironment() {
        appendTerminal("[*] LegitivLinux v1.18.1: проверка окружения...")
        val profile = assistantEngine.detectHardwareProfile()
        appendTerminal("[*] ABI: ${profile.architecture} | GPU path: ${profile.vulkanDriver}")
        profile.warningMessage?.let { appendTerminal("[!] $it") }
        scope.launch(Dispatchers.IO) {
            if (!prootInstaller.isReady()) {
                withContext(Dispatchers.Main) { statusText.text = "Установка Debian ARM64..." }
                val ok = prootInstaller.extractEmbeddedRootfs { appendTerminal(it) }
                withContext(Dispatchers.Main) { statusText.text = if (ok) "Debian установлен" else "Требуется PRoot bootstrap" }
            } else withContext(Dispatchers.Main) { statusText.text = "Linux окружение готово" }
        }
    }

    private fun startBackgroundService() {
        val intent = Intent(this, TermuxService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }

    private fun checkPhantomProcessKiller() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) appendTerminal("[!] Для долгих процессов желательно отключить оптимизацию батареи для приложения.")
    }

    private fun showPhantomProcessGuide() {
        appendTerminal("--- Рекомендации ---")
        appendTerminal("Отключение battery optimization: Настройки → Приложения → LegitivLinux → Батарея → Без ограничений.")
        appendTerminal("ADB-настройки Phantom Process зависят от производителя Android и не применяются приложением автоматически.")
    }

    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            // Do not force the settings screen; shared storage is optional.
            appendTerminal("[*] Общая память: доступ можно выдать позже через настройки Android.")
        }
    }
}
