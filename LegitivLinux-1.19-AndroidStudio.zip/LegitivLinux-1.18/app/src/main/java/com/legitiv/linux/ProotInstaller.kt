package com.legitiv.linux

import android.content.Context
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader

class ProotInstaller(private val context: Context) {
    private val usrDir = File(context.filesDir, "usr")
    private val rootfsDir = File(usrDir, "rootfs")
    private val binDir = File(usrDir, "bin")
    private val componentManager = ComponentManager(context)

    private fun ensureBundledProot(onProgress: (String) -> Unit): Boolean {
        val target = File(binDir, "proot")
        if (target.canExecute()) return true
        return try {
            context.assets.open("bin/proot").use { input ->
                target.parentFile?.mkdirs()
                target.outputStream().use { input.copyTo(it) }
            }
            target.setExecutable(true, false)
            onProgress("[+] Встроенный PRoot установлен: ${target.absolutePath}")
            true
        } catch (_: Exception) {
            false
        }
    }

    fun extractEmbeddedRootfs(onProgress: (String) -> Unit): Boolean {
        ensureBundledProot(onProgress)
        // v1.19 deliberately refuses the old fake README-only assets.
        // Runtime rootfs is downloaded and verified by ComponentManager.
        onProgress("Проверка Debian ARM64 rootfs...")
        val c = componentManager.manifest().first()
        if (!componentManager.download(c, onProgress)) {
            onProgress("[-] Не удалось получить проверенный Debian rootfs.")
            return false
        }
        return extractTar(c.output, onProgress)
    }

    private fun extractTar(archive: File, onProgress: (String) -> Unit): Boolean {
        return try {
            rootfsDir.mkdirs()
            org.tukaani.xz.XZInputStream(archive.inputStream().buffered()).use { xz ->
                org.apache.commons.compress.archivers.tar.TarArchiveInputStream(xz).use { tar ->
                    var entry = tar.nextTarEntry
                    while (entry != null) {
                        val raw = entry.name.trimStart('/')
                        val parts = raw.split('/').filter { it.isNotEmpty() }
                        if (parts.isNotEmpty()) {
                            // PRoot-Distro archives contain one top-level distro directory.
                            val relative = if (parts.size > 1) parts.drop(1).joinToString("/") else ""
                            if (relative.isNotEmpty() && relative != ".") {
                                val out = File(rootfsDir, relative).canonicalFile
                                if (!out.path.startsWith(rootfsDir.canonicalPath + File.separator)) throw SecurityException("Unsafe archive path")
                                if (entry.isDirectory) out.mkdirs() else {
                                    out.parentFile?.mkdirs()
                                    FileOutputStream(out).use { tar.copyTo(it) }
                                    if ((entry.mode and 0b001001001) != 0) out.setExecutable(true, false)
                                }
                            }
                        }
                        entry = tar.nextTarEntry
                    }
                }
            }
            setupFilesystem()
            archive.delete()
            File(rootfsDir, "bin/sh").exists()
        } catch (e: Exception) {
            onProgress("[-] Распаковка rootfs: ${e.message}")
            false
        }
    }

    private fun setupFilesystem() {
        listOf("dev", "proc", "sys", "sdcard", "storage", "tmp", "root").forEach { File(rootfsDir, it).mkdirs() }
        val resolv = File(rootfsDir, "etc/resolv.conf")
        resolv.parentFile?.mkdirs()
        resolv.writeText("nameserver 1.1.1.1\nnameserver 8.8.8.8\n")
        File(rootfsDir, "root/.bashrc").apply {
            parentFile?.mkdirs()
            writeText("export HOME=/root\nexport TERM=xterm-256color\nexport PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n")
        }
    }

    fun isReady(): Boolean = File(rootfsDir, "bin/sh").exists()

    fun executeInProot(command: String, onOutputLine: (String) -> Unit) {
        ensureBundledProot(onOutputLine)
        val proot = File(binDir, "proot")
        if (!proot.canExecute()) {
            onOutputLine("[-] PRoot не установлен в ${proot.absolutePath}.")
            onOutputLine("[*] Соберите/установите PRoot ARM64 из tools/build-proot-arm64.sh.")
            return
        }
        if (!isReady()) {
            onOutputLine("[-] Debian rootfs ещё не установлен. Нажмите инициализацию/перезапустите приложение.")
            return
        }
        val args = listOf(
            proot.absolutePath, "--kill-on-exit", "--link2symlink", "-0",
            "-r", rootfsDir.absolutePath, "-b", "/dev", "-b", "/proc", "-b", "/sys",
            "-b", "/storage", "-b", "/sdcard:/sdcard", "-w", "/root", "/bin/sh", "-c", command
        )
        try {
            val process = ProcessBuilder(args).redirectErrorStream(true).start()
            BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                reader.forEachLine(onOutputLine)
            }
            val code = process.waitFor()
            onOutputLine("[exit=$code]")
        } catch (e: Exception) {
            onOutputLine("[-] Ошибка PRoot: ${e.message}")
        }
    }
}
