package com.legitiv.linux

import android.content.Context
import java.io.File

class WineGamingManager(private val context: Context) {

    private val prootInstaller = ProotInstaller(context)

    fun launchSteam(onOutput: (String) -> Unit) {
        onOutput("[*] Проверка x86_64 транслятора Box64...")
        onOutput("[*] Инициализация окружения Steam Client (No-Browser / Minimal)...")
        
        val steamScript = """
export BOX64_DYNAREC=1
export BOX64_DYNAREC_FASTROUND=1
export BOX64_DYNAREC_SAFEFLAGS=1
export BOX64_DYNAREC_BIGBLOCK=1
export BOX64_ALLOW_ADDR32=1
export BOX64_PREFER_WRAPPERS=1
export STEAM_RUNTIME=1
export DISPLAY=:0
export WINEPREFIX=/root/.wine_steam

echo "[Steam Launcher] Box64 Dynarec окружение инициализировано."
echo "[Steam Launcher] Запуск Steam CMD / Steam Lite client..."
box64 /usr/games/steam/steam.exe -no-browser +open steam://open/minigameslist 2>&1
"""
        prootInstaller.executeInProot(steamScript, onOutput)
    }

    fun launchWineExplorer(onOutput: (String) -> Unit) {
        onOutput("[*] Инициализация Wine runtime...")
        val wineScript = """
export DISPLAY=:0
export WINEPREFIX=/root/.wine
export DXVK_HUD=fps,memory,version
export MESA_LOADER_DRIVER_OVERRIDE=zink
export TU_DEBUG=noconform
export BOX64_ALLOW_ADDR32=1

echo "[Wine Manager] Wine prefix: /root/.wine"
echo "[Wine Manager] DXVK активирован при наличии установленного runtime. Запуск explorer.exe..."
box64 wine explorer /desktop=shell,1280x720 2>&1
"""
        prootInstaller.executeInProot(wineScript, onOutput)
    }
}
