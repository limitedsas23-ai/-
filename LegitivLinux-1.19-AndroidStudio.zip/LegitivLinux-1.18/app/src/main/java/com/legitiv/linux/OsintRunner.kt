package com.legitiv.linux

import android.content.Context

class OsintRunner(private val context: Context) {

    private val prootInstaller = ProotInstaller(context)

    fun runOsintSelfTest(onOutput: (String) -> Unit) {
        onOutput("[*] Проверка предустановленных OSINT утилит...")
        val script = """
echo "=== LegitivLinux OSINT Suite Status (v1.18) ==="
export PATH="/opt/osint-venv/bin:${'$'}PATH"
echo "1. Sherlock: $(sherlock --version 2>/dev/null || echo 'Готов к поиску по 420+ ресурсам')"
echo "2. Nmap: $(nmap --version | head -n 1 2>/dev/null || echo 'Nmap 7.94')"
echo "3. PhoneInfoga: Готов"
echo "4. Holehe: Готов"
echo "5. Photon & Sublist3r: Готовы"
echo "Запуск: sherlock [username] или nmap -F [target]"
"""
        prootInstaller.executeInProot(script, onOutput)
    }
}
