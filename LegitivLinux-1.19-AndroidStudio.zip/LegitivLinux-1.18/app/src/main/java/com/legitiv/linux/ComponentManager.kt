package com.legitiv.linux

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Downloads only verified runtime components; no fake embedded binaries. */
class ComponentManager(private val context: Context) {
    data class Component(val name: String, val url: String, val sha256: String, val output: File)

    private val base = File(context.filesDir, "usr")
    private val cache = File(context.cacheDir, "components")

    fun manifest(): List<Component> {
        cache.mkdirs()
        return listOf(
            Component("Debian ARM64 rootfs", "https://github.com/termux/proot-distro/releases/download/v1.10.1/debian-aarch64-pd-v1.10.1.tar.xz", "f34802fbb300b4d088a638c638683fd2bfc1c03f4b40fa4cb7d2113231401a21", File(cache, "debian-aarch64.tar.xz"))
        )
    }

    fun verify(file: File, expected: String): Boolean {
        if (!file.isFile) return false
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(1024 * 1024)
            var n: Int
            while (input.read(buf).also { n = it } > 0) md.update(buf, 0, n)
        }
        return md.digest().joinToString("") { "%02x".format(it) }.equals(expected, true)
    }

    fun download(c: Component, progress: (String) -> Unit): Boolean {
        if (verify(c.output, c.sha256)) return true
        val tmp = File(c.output.parentFile, c.output.name + ".part")
        val conn = (URL(c.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30000; readTimeout = 120000; requestMethod = "GET"
        }
        return try {
            conn.connect()
            if (conn.responseCode !in 200..299) return false
            val total = conn.contentLengthLong
            var done = 0L
            conn.inputStream.use { input -> tmp.outputStream().use { out ->
                val buf = ByteArray(1024 * 1024); var n: Int
                while (input.read(buf).also { n = it } > 0) {
                    out.write(buf, 0, n); done += n
                    if (total > 0) progress("Загрузка ${c.name}: ${done * 100 / total}%")
                }
            }}
            if (!verify(tmp, c.sha256)) { tmp.delete(); return false }
            if (c.output.exists()) c.output.delete()
            tmp.renameTo(c.output)
            true
        } finally { conn.disconnect() }
    }
}
