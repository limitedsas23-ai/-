#include <jni.h>
#include <pty.h>
#include <unistd.h>
#include <fcntl.h>
#include <android/log.h>

#define TAG "LegitivTermuxPTY"

extern "C" JNIEXPORT jint JNICALL
Java_com_legitiv_linux_MainActivity_createSubprocess(
    JNIEnv *env,
    jobject thiz,
    jstring cmd,
    jobjectArray args,
    jobjectArray envVars,
    jintArray processIdArray
) {
    int ptm = -1;
    pid_t pid = forkpty(&ptm, nullptr, nullptr, nullptr);

    if (pid < 0) {
        __android_log_print(ANDROID_LOG_ERROR, TAG, "forkpty failed");
        return -1;
    }

    if (pid == 0) {
        // Дочерний процесс PRoot
        execl("/system/bin/sh", "sh", "-l", nullptr);
        _exit(1);
    }

    // Родительский процесс Termux
    jint *pids = env->GetIntArrayElements(processIdArray, nullptr);
    if (pids != nullptr) {
        pids[0] = pid;
        env->ReleaseIntArrayElements(processIdArray, pids, 0);
    }

    return ptm;
}
