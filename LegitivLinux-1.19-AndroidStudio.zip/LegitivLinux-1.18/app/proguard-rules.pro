# LegitivLinux: keep runtime manager classes and JNI entry points.
-keep class com.legitiv.linux.** { *; }
